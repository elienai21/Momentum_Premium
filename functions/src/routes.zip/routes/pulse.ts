// functions/src/routes/pulse.ts
import { Request, Response, Router } from "express";
import * as admin from "firebase-admin";
import crypto from "crypto";


// Garante que o Firebase Admin esteja inicializado mesmo se
// este módulo for carregado antes do index.ts
if (!admin.apps.length) {
  admin.initializeApp();
}

const db = admin.firestore();


// ---- Tipos ----
type Tx = {
  id: string;
  date: FirebaseFirestore.Timestamp | Date | string;
  amount: number;
  type?: "in" | "out";
  category?: string;
  status?: "paid" | "pending" | "overdue";
};

type SummaryKPIs = {
  cash_in: number;
  cash_out: number;
  net_cash: number;
  opening_balance: number;
  closing_balance: number;
  runway_days: number | null;
};

type DailyBalancePoint = {
  date: string; // YYYY-MM-DD
  balance: number;
};

type AccountRow = {
  id: string;
  name: string;
  dueDate?: string;
  amount?: number;
  status?: string;
  type?: string;
};

type AlertRow = {
  id: string;
  type: string;
  message: string;
  createdAt: string;
  read?: boolean;
};

type SummaryResponse = {
  tenantId: string;
  period: {
    start: string;
    end: string;
  };
  kpis: SummaryKPIs;
  inflows: {
    total: number;
    byCategory: Record<string, number>;
  };
  outflows: {
    total: number;
    byCategory: Record<string, number>;
  };
  balanceSeries: DailyBalancePoint[];
  accounts: AccountRow[];
  alerts: AlertRow[];
  projections: {
    runwayText: string;
  };
  meta: {
    traceId: string;
    latency_ms: number;
  };
};

// ---- Cache em memória (TTL 60s) ----
const CACHE_TTL_MS = 60_000;
const memCache = new Map<string, { exp: number; data: SummaryResponse }>();

function cacheKey(tenantId: string, startISO: string, endISO: string) {
  return crypto
    .createHash("sha256")
    .update(`${tenantId}|${startISO}|${endISO}`)
    .digest("hex");
}

// Helpers de datas
function parseDateParam(value: string | undefined, fallback: Date): Date {
  if (!value) return fallback;
  const d = new Date(value);
  return isNaN(d.getTime()) ? fallback : d;
}

function asDate(v: FirebaseFirestore.Timestamp | Date | string | null | undefined): Date {
  if (!v) return new Date();
  if (v instanceof Date) return v;
  if (typeof (v as any).toDate === "function") return (v as any).toDate();
  if (typeof v === "string") return new Date(v);
  return new Date();
}

function round2(n: number) {
  return Math.round((n + Number.EPSILON) * 100) / 100;
}

function objectRound2(rec: Record<string, number>) {
  return Object.fromEntries(Object.entries(rec).map(([k, v]) => [k, round2(v)]));
}

// Itera transações/entries do tenant usando coleções conhecidas
async function* iterateTenantEntries(
  tenantId: string,
  start: Date,
  end: Date
): AsyncGenerator<Tx> {
  const candidates = [
    `tenants/${tenantId}/transactions`,
    `tenants/${tenantId}/entries`,
    `tenants/${tenantId}/ledger`,
  ];

  for (const path of candidates) {
    const ref = db.collection(path);
    const snap = await ref
      .where("date", ">=", start.toISOString())
      .where("date", "<=", end.toISOString())
      .orderBy("date", "asc")
      .limit(2000)
      .get()
      .catch(() => null);

    if (!snap || snap.empty) continue;

    for (const doc of snap.docs) {
      const data = doc.data();
      yield {
        id: doc.id,
        date: data.date ?? data.dueDate ?? data.createdAt ?? new Date().toISOString(),
        amount: Number(data.amount ?? data.value ?? 0),
        type: data.type,
        category: data.category || data.group || data.tag,
        status: data.status,
      };
    }

    break; // encontrou uma coleção válida, não tenta as demais
  }
}

// Carrega contas básicas (a pagar / a receber)
async function loadAccounts(tenantId: string): Promise<AccountRow[]> {
  const snap = await db
    .collection(`tenants/${tenantId}/accounts`)
    .orderBy("dueDate", "asc")
    .limit(100)
    .get()
    .catch(() => null);

  if (!snap || snap.empty) return [];

  return snap.docs.map((doc) => {
    const data = doc.data();
    return {
      id: doc.id,
      name: data.name ?? data.description ?? "Conta",
      dueDate: data.dueDate
        ? new Date(data.dueDate).toISOString()
        : data.dueDateISO ?? null,
      amount: typeof data.amount === "number" ? data.amount : undefined,
      status: data.status,
      type: data.type,
    };
  });
}

// Carrega alertas recentes
async function loadAlerts(tenantId: string): Promise<AlertRow[]> {
  const snap = await db
    .collection(`tenants/${tenantId}/alerts`)
    .orderBy("createdAt", "desc")
    .limit(20)
    .get()
    .catch(() => null);

  if (!snap || snap.empty) return [];

  return snap.docs.map((doc) => {
    const data = doc.data();
    return {
      id: doc.id,
      type: data.type ?? "generic",
      message: data.message ?? "",
      createdAt: data.createdAt ?? new Date().toISOString(),
      read: data.read ?? false,
    };
  });
}

const pulseRouter = Router();

/**
 * GET /api/pulse/summary?start=YYYY-MM-DD&end=YYYY-MM-DD
 * Requer req.tenant.id (via middleware upstream). Se não houver, aceita ?tenantId=.
 *
 * Path final usando o index.ts:
 *   app.use("/api", router);
 *   router.use("/pulse", pulseRouter);
 *   pulseRouter.get("/summary", ...)
 * => /api/pulse/summary
 */
pulseRouter.get("/summary", async (req: Request, res: Response) => {
  const t0 = Date.now();
  const traceId = (req.headers["x-trace-id"] as string) ?? crypto.randomUUID();

  try {
    const tenantId =
      (req as any).tenant?.id ||
      (req as any).tenant?.info?.id ||
      (req.query.tenantId as string);

    if (!tenantId) {
      return res.status(400).json({
        ok: false,
        error: "tenant_required",
        traceId,
      });
    }

    const today = new Date();
    const defaultStart = new Date(today);
    defaultStart.setDate(defaultStart.getDate() - 29);

    const start = parseDateParam(req.query.start as string | undefined, defaultStart);
    const end = parseDateParam(req.query.end as string | undefined, today);

    const startISO = start.toISOString().slice(0, 10);
    const endISO = end.toISOString().slice(0, 10);

    const key = cacheKey(tenantId, startISO, endISO);
    const cached = memCache.get(key);
    if (cached && cached.exp > Date.now()) {
      return res.json(cached.data);
    }

    // ================================
    // 🔢 Agregação de transações
    // ================================
    let cashIn = 0;
    let cashOut = 0;
    const inflowByCat: Record<string, number> = {};
    const outflowByCat: Record<string, number> = {};
    const dailyBalance: Record<string, number> = {};

    // Saldo inicial simples (se precisar, pode evoluir para buscar antes de start)
    let balance = 0;

    for await (const tx of iterateTenantEntries(tenantId, start, end)) {
      const d = asDate(tx.date);
      const dayKey = d.toISOString().slice(0, 10);
      const rawAmount = typeof tx.amount === "number" ? tx.amount : 0;

      const isOut = rawAmount < 0 || tx.type === "out";
      const amt = Math.abs(rawAmount);

      if (isOut) {
        cashOut += amt;
        const cat = tx.category || "Outros";
        outflowByCat[cat] = (outflowByCat[cat] ?? 0) + amt;
        balance -= amt;
      } else {
        cashIn += amt;
        const cat = tx.category || "Outros";
        inflowByCat[cat] = (inflowByCat[cat] ?? 0) + amt;
        balance += amt;
      }

      dailyBalance[dayKey] = balance;
    }

    const openingBalance = 0; // pode ser evoluído depois
    const closingBalance = balance;
    const netCash = cashIn - cashOut;

    // Runway simples: se netCash<0, quantos dias de caixa com base no burn médio diário
    let runway_days: number | null = null;
    if (netCash < 0 && closingBalance > 0) {
      const days = Math.max(1, Object.keys(dailyBalance).length || 30);
      const avgBurn = Math.abs(netCash) / days;
      runway_days = avgBurn > 0 ? closingBalance / avgBurn : null;
    }

    const kpis: SummaryKPIs = {
      cash_in: round2(cashIn),
      cash_out: round2(cashOut),
      net_cash: round2(netCash),
      opening_balance: round2(openingBalance),
      closing_balance: round2(closingBalance),
      runway_days: runway_days ? round2(runway_days) : null,
    };

    // Ordena série de saldo diário
    const balanceSeries: DailyBalancePoint[] = Object.entries(dailyBalance)
      .sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0))
      .map(([date, value]) => ({ date, balance: round2(value) }));

    // ================================
    // 📄 Contas & Alertas
    // ================================
    const [accounts, alerts] = await Promise.all([
      loadAccounts(tenantId),
      loadAlerts(tenantId),
    ]);

    const response: SummaryResponse = {
      tenantId,
      period: {
        start: startISO,
        end: endISO,
      },
      kpis,
      inflows: {
        total: round2(cashIn),
        byCategory: objectRound2(inflowByCat),
      },
      outflows: {
        total: round2(cashOut),
        byCategory: objectRound2(outflowByCat),
      },
      balanceSeries,
      accounts,
      alerts,
      projections: {
        runwayText:
          runway_days && runway_days > 0
            ? `Runway estimado de aproximadamente ${Math.round(runway_days)} dias com o saldo atual.`
            : "Runway não disponível com os dados atuais.",
      },
      meta: {
        traceId,
        latency_ms: Date.now() - t0,
      },
    };

    memCache.set(key, { exp: Date.now() + CACHE_TTL_MS, data: response });

    return res.json(response);
  } catch (err: any) {
    console.error("pulse/summary error", {
      traceId,
      error: err?.message,
      stack: err?.stack,
    });

    return res.status(500).json({
      ok: false,
      error: "internal_error",
      traceId,
    });
  }
});

export default pulseRouter;

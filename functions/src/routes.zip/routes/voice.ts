// functions/src/routes/voice.ts
import { Request, Response, Router } from "express";
import { synthesizeToGcs } from "../services/ttsService";
import { transcribeFromGcs } from "../services/sttService";

const voiceRouter = Router();

// Tipagem básica para pegar tenant, se o withTenant já estiver preenchendo req.tenant
type AuthedRequest = Request & {
  tenant?: { info?: { id: string } };
  user?: { uid: string };
};

// POST /api/voice/tts
// Body: { text: string; lang?: string; voiceName?: string }
voiceRouter.post(
  "/voice/tts",
  async (req: AuthedRequest, res: Response): Promise<void> => {
    const { text, lang = "pt-BR", voiceName } = req.body || {};

    if (!text || typeof text !== "string") {
      res.status(400).json({ error: "Campo 'text' é obrigatório." });
      return;
    }

    const tenantId = req.tenant?.info?.id || "anon";

    try {
      const result = await synthesizeToGcs({
        tenantId,
        text,
        lang,
        voiceName,
      });

      // result esperado: { cached: boolean; url: string }
      res.status(200).json({
        audioUrl: result.url,
        cached: result.cached,
      });
    } catch (err: any) {
      // Caso VOICE_BUCKET não esteja configurado, o service lança VOICE_DISABLED
      const code = err?.code || "TTS_ERROR";
      const status = err?.status || (code === "VOICE_DISABLED" ? 503 : 500);

      // eslint-disable-next-line no-console
      console.error("Erro ao gerar TTS", err);

      res.status(status).json({
        error:
          code === "VOICE_DISABLED"
            ? "Funcionalidade de voz não está configurada neste ambiente."
            : "Erro ao gerar TTS.",
        code,
      });
    }
  }
);

// POST /api/voice/stt
// Body: { gcsUri: string; languageCode?: string }
// (você pode chamar isso de audioUrl no front, mas aqui usamos gcsUri explicitamente)
voiceRouter.post(
  "/voice/stt",
  async (req: AuthedRequest, res: Response): Promise<void> => {
    const { gcsUri, languageCode = "pt-BR" } = req.body || {};

    if (!gcsUri || typeof gcsUri !== "string") {
      res.status(400).json({ error: "Campo 'gcsUri' é obrigatório." });
      return;
    }

    try {
      const result = await transcribeFromGcs({
        tenantId: req.tenant?.info?.id || "anon",
        gcsUri,
        languageCode,
      });

      // result esperado: { text: string }
      res.status(200).json({ transcript: result.text });
    } catch (err: any) {
      const code = err?.code || "STT_ERROR";
      const status = err?.status || (code === "VOICE_DISABLED" ? 503 : 500);

      // eslint-disable-next-line no-console
      console.error("Erro ao transcrever áudio", err);

      res.status(status).json({
        error:
          code === "VOICE_DISABLED"
            ? "Funcionalidade de voz não está configurada neste ambiente."
            : "Erro ao transcrever áudio.",
        code,
      });
    }
  }
);

export { voiceRouter };

// functions/src/routes/billing.ts
import { Router } from "express";
import { ApiError } from "../utils/errors";
import { getCredits } from "../billing/creditsService";
import { PlanTier } from "../billing/creditsTypes";

export const billingRouter = Router();

// GET /api/billing/credits
billingRouter.get("/credits", async (req: any, res, next) => {
  try {
    if (!req.tenant) throw new ApiError(400, "Tenant context required");

    const tenantId = req.tenant.info.id;
    const planId = (req.tenant.info.plan || "starter") as PlanTier;

    const state = await getCredits(tenantId, planId);

    res.json({
      status: "ok",
      credits: {
        available: state.available,
        monthlyQuota: state.monthlyQuota,
        used: state.used,
        renewsAt: state.renewsAt,
      },
    });
  } catch (e: any) {
    next(
      new ApiError(
        500,
        e.message || "Erro ao carregar créditos de IA",
        req.traceId
      )
    );
  }
});

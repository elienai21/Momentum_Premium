import { db } from "../services/firebase";
import express from "express";
import { runAdvisor } from "../ai/advisor";
import { requireAuth } from "../middleware/requireAuth";

const router = express.Router();

// POST /api/advisor
router.post("/", requireAuth, runAdvisor);

export default router;


